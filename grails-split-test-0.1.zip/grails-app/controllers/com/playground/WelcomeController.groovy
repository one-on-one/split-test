package com.playground

class WelcomeController {

    def splitTestService

    def index() { }

    def converted() {
        splitTestService.markTestAsActionOneConverted('My First Split Test')
    }
}
